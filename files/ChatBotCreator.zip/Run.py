import discord
import requests
import urllib.parse

# --- Configuration ---
DISCORD_TOKEN_FILE = "DiscordToken.txt"
SYSTEM_PROMPT_FILE = "SystemIntroductions.txt"
IMAGE_PROMPT_FILE = "ImagePrompt(don't_change!).txt"
IMAGE_GENERATION_ON_OFF_FILE = "ImageGenerationOnOff.txt"

# --- Character Limits ---
TOTAL_CHAR_LIMIT = 5000
IMAGE_PROMPT_RESERVED = 200
SYSTEM_PROMPT_RESERVED = 800
MEMORY_RESERVED = 2000
USER_PROMPT_RESERVED = 2000

# --- In-memory conversation history ---
conversation_history = []

# --- Helper Functions ---
def get_discord_token():
    """Reads the Discord token from the file."""
    try:
        with open(DISCORD_TOKEN_FILE, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        print(f"Error: {DISCORD_TOKEN_FILE} not found. Please create it and add your Discord bot token.")
        exit()

def get_system_prompt():
    """Reads the system prompt from the file."""
    try:
        with open(SYSTEM_PROMPT_FILE, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except FileNotFoundError:
        return ""

def get_image_generation_settings():
    """Reads the image generation prompt and its on/off status."""
    try:
        with open(IMAGE_GENERATION_ON_OFF_FILE, 'r') as f:
            lines = f.readlines()
            is_on = lines[1].strip() == '1' if len(lines) > 1 else False
    except (FileNotFoundError, IndexError):
        is_on = False

    if is_on:
        try:
            with open(IMAGE_PROMPT_FILE, 'r', encoding='utf-8') as f:
                prompt = f.read().strip()
                return is_on, prompt
        except FileNotFoundError:
            return False, ""
    return False, ""

def build_prompt(user_message):
    """Builds the final prompt to be sent to the AI, managing character limits."""
    system_prompt = get_system_prompt()
    image_on, image_prompt_text = get_image_generation_settings()

    current_memory_limit = MEMORY_RESERVED
    image_prompt_section = ""

    if image_on and image_prompt_text:
        image_prompt_section = f"{image_prompt_text}\n"
    else:
        # If image generation is off, add its reserved characters to memory
        current_memory_limit += IMAGE_PROMPT_RESERVED

    # Build memory string
    memory_string = ""
    temp_memory = ""
    for entry in reversed(conversation_history):
        temp_memory = f"user: {entry['user']}\nmodel: {entry['model']}\n" + temp_memory
        if len(temp_memory) <= current_memory_limit:
            memory_string = temp_memory
        else:
            break # Stop adding older history if it exceeds the limit

    # Truncate components to their reserved limits
    final_system_prompt = system_prompt[:SYSTEM_PROMPT_RESERVED]
    final_image_prompt = image_prompt_section[:IMAGE_PROMPT_RESERVED]
    final_user_message = user_message[:USER_PROMPT_RESERVED]


    full_prompt = (
        f"{final_image_prompt}"
        f"{final_system_prompt}\n"
        f"{memory_string}"
        f"recent user response: {final_user_message}"
    )

    return full_prompt[:TOTAL_CHAR_LIMIT]

# --- Discord Bot ---
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'We have logged in as {client.user}')

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    # Construct the prompt
    user_input = message.content
    prompt_to_send = build_prompt(user_input)
    encoded_prompt = urllib.parse.quote(prompt_to_send)
    url = f"https://text.pollinations.ai/prompt/{encoded_prompt}"

    try:
        async with message.channel.typing():
            # Send request to the AI
            response = requests.get(url)
            response.raise_for_status()  # Raise an exception for bad status codes

            ai_response = response.text

            # Update conversation history
            conversation_history.append({"user": user_input, "model": ai_response})

            # Send the AI's response to Discord
            if ai_response:
                await message.reply(ai_response, mention_author=False)
            else:
                await message.reply("I received an empty response. Please try again.", mention_author=False)


    except requests.exceptions.RequestException as e:
        print(f"Error calling the AI API: {e}")
        await message.reply("Sorry, I'm having trouble connecting to the AI. Please try again later.", mention_author=False)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        await message.reply("An unexpected error occurred. Please check the console for details.", mention_author=False)


if __name__ == "__main__":
    TOKEN = get_discord_token()
    if TOKEN:
        client.run(TOKEN)